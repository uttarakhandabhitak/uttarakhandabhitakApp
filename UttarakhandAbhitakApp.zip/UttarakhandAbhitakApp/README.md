# उत्तराखंड अभीतक Android App

यह Android Studio project `https://uttarakhandabhitak.com/` को ऐप के अंदर खोलता है और दिए गए लोगो को app icon के रूप में उपयोग करता है।

## Build
1. Android Studio में यह पूरा folder खोलें।
2. Gradle sync होने दें।
3. `Build > Generate App Bundles or APKs > Generate App Bundle` चुनें।
4. Play Store के लिए signed AAB बनाएं।

Application ID: `com.uttarakhandabhitak.app`
Version: `1.0 (1)`
