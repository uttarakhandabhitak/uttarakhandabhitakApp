package com.uttarakhandabhitak.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.webkit.DownloadListener;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private static final String HOME = "https://uttarakhandabhitak.com/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(90,90);
        p.gravity = android.view.Gravity.CENTER;
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        root.addView(progress, p);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                v.loadUrl(r.getUrl().toString()); return true;
            }
            @Override public void onPageFinished(WebView v, String url){ progress.setVisibility(View.GONE); }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {}
        });
        webView.loadUrl(HOME);
    }
    @Override public void onBackPressed(){
        if(webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
